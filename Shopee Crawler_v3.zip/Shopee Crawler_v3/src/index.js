require('dotenv').config({ path: '.env' });

global.gHelper = require('./helper');

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const _ = require('lodash');
const moment = require("moment-timezone");
const busboy = require('connect-busboy');
const csv = require('fast-csv');

const Shopee = require('./lib/shopee');
const ExportProduct = require('./lib/export_product');

const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.disable('x-powered-by');
app.use(express.static('src/public'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(busboy());

const serverCore = require("http").createServer(app);

(() => {
    if(!fs.existsSync('temp')){
        fs.mkdirSync('temp');
    }
    if(!fs.existsSync(path.join('src', 'public', 'export'))){
        fs.mkdirSync(path.join('src','public', 'export'), { recursive: true });
    }
    Shopee.startAutoUpdate();
    Shopee.startRunEndOfDay();
})();

app.use(function(req, res, next) {
    res.locals.query = req.query;
    res.locals.originalUrl = req.originalUrl;
    res.setHeader('X-Powered-By', 'Window Server XP');
    next();
});

app.get('/', (req, res) => {
    let list = Shopee.getProducts();
    list = list.map(item => {
        let sold_list = Object.values(item.historical_sold_time);
        let sold_increase = 0;
        if(sold_list.length > 1){
            sold_increase = sold_list[sold_list.length - 1] - sold_list[0];
        }
        return {
            ...item,
            sold_count: sold_list.length,
            sold_increase
        };
    });
    list = _.orderBy(list, ['sold_count', 'sold_increase'], ['desc', 'desc']);
    return res.render('home', { list });
});

app.get('/export/:type', (req, res) => {
    let { type } = req.params || {};
    if(type !== 'csv'){
        return res.send('File type is invalid');
    }

    let list = Shopee.getProducts();
    list = _.orderBy(list, item => Object.keys(item.historical_sold_time).length, 'desc');
    list = _.take(list, 300);

    let exportProduct = new ExportProduct(list);
    let filename = path.join('temp', `Product ${moment().tz('Asia/Ho_Chi_Minh').format('YYYY-MM-DD HH.mm.ss')}.${type}`);

    exportProduct.toCsv(filename);

    res.download(filename, function () {
        fs.rmSync(filename);
    });
});

app.post('/export-condition', (req, res) => {
    try{
        req.pipe(req.busboy);
        req.busboy.on('file', function (field_name, file, filename) {
            let list = Shopee.getProducts();

            let compare = {};
            file.pipe(csv.parse({ headers: true }))
                .on('error', error => console.error(error))
                .on('data', row => {
                    let row_index = row[''];
                    let product_id = row['Links'].split('?').shift().split('.').pop();
                    let rating = row['Rating'];
                    let product = list.find(item => item.id == product_id);
                    if(product_id && product){
                        compare[`s${product_id}`] = { ...product, row_index, rating };
                    }
                })
                .on('end', rowCount => {
                    console.log('All com', rowCount);
                    let exportProduct = new ExportProduct(Object.values(compare));
                    let filename = `Product condition ${moment().tz('Asia/Ho_Chi_Minh').format('YYYY-MM-DD HH.mm.ss')}.csv`;

                    exportProduct.toCsv(path.join('src', 'public', 'export', filename), { extend: true });
                    return res.json({ success: true, data: { filename: `/export/${filename}` } });
                });
        });
    } catch (e) {
        return res.json({ success: false, message: e.message });
    }
});

app.get('/historical-sold', (req, res) => {
    let { product_id } = req.query || {};
    if(!product_id){
        return res.json({ success: false, message: 'Params invalid!' });
    }
    let product = Shopee.getDetail(product_id);
    if(!product){
        return res.json({ success: false, message: 'Can not found the product' });
    }
    let historical_sold_time = product.historical_sold_time;
    let data = Object.keys(historical_sold_time).reduce((a, c, currentIndex) => ({ ...a, [c]: currentIndex > 0 ? historical_sold_time[c] - historical_sold_time[Object.keys(a).pop()] : 0 }), {});
    return res.json({ success: true, message: 'Success', data: data, historical_sold_time });
});

const server = serverCore.listen(process.env.SERVER_PORT || 5000, () => {
    console.log(`Server running → PORT ${server.address().port}`);
});