$(function () {
    $.get('https://api.ipify.org?format=json').then(data => {
        if(data && data.ip && data.ip.includes('.')){
            $.ajaxSetup({
                headers: { 'cl_ip': data.ip }
            });
        }
    });

    $('.rating_star').each(function () {
        let star = parseFloat($(this).attr('data-rating')) || 0;
        if(star > 5){ star = 5; }
        let full = Math.floor(star);
        let hasHalf = (star - full) >= 0.5;
        let rest = Math.ceil(star - full + (hasHalf ? -1 : 0));
        let starString = full > 0 ? [...Array(full).keys()].map(i => `<i class="fas fa-star rating_star--active"></i>`).join('') : '';
        starString += (hasHalf ? '<i class="fas fa-star-half-alt rating_star--active"></i>' : '');
        starString += rest > 0 ? [...Array(rest).keys()].map(i => `<i class="far fa-star rating_star--deactive"></i>`).join('') : '';
        $(this).html(starString);
    });

    $('.product__item').each(function () {
        let sold_count = parseInt($(this).attr('data-sold_count'));
        let sold_increase = parseInt($(this).attr('data-sold_increase'));
        if(sold_count < 2){
            $(this).find('.justify-content-end').prepend(`<span class="badge badge-pill badge-warning mr-1 mr-sm-2">Record: ${sold_count}</span>`);
        } else {
            $(this).find('.justify-content-end').prepend(`<span class="badge badge-pill badge-success mr-1 mr-sm-2">Increase: ${sold_increase}</span>`);
            $(this).find('.justify-content-end').prepend(`<span class="badge badge-pill badge-success mr-1 mr-sm-2">Record: ${sold_count}</span>`);
            $(this).removeClass('border-danger').addClass('border-success product__item--cheapest-deal');
        }
    });

    $('.btn-voucher').click(function () {
        let code = $(this).attr('data-code');
        navigator.clipboard.writeText(code).then(function() {
            $.notify('Đã copy voucher vào clipboard!', { position: 'top right', className: 'success' });
        }, function(err) {
            $.notify('Lỗi copy voucher: ' + err.message, { position: 'top right', className: 'error' });
        });
    });

    $('input[type="file"]').on('change', function (event){
        if(event.target.files && event.target.files.length){
            let form = new FormData();
            form.append('file', event.target.files[0]);
            $.ajax({
                type: 'POST',
                url:"/export-condition",
                data: form,
                processData: false,
                contentType: false,
                success: ({ success, data, message }) => {
                    if(success && data){
                        var win = window.open(data.filename, '_blank');
                        if (win) {
                            win.focus();
                        } else {
                            $.notify('Please allow popups for this website', { position: 'top right', className: 'error' });
                        }
                    } else {
                        $.notify(message, { position: 'top right', className: 'error' });
                    }
                    $(this).val(null);
                }
            });
        }
    });

    $('.btn-download-excel').click(function () {
        $('input[type="file"]').trigger('click');
    });

    const ctx = document.getElementById('myChart');
    var chart = null;
    $('.btn-historical-price').click(function () {
        let product_id = $(this).closest('.product__item').attr('data-id');
        $.get(`/historical-sold?product_id=${product_id}`).then(({ data, success, message }) => {
            if(!success){
                message && $.notify(message, { position: 'top right', className: 'error' });
                return;
            }
            let dates = Object.keys(data);
            if(dates.length < 2){
                $.notify('Chờ thay đổi giá trị bán để hiển thị', { position: 'top right', className: 'error' });
                return;
            }
            let sold = Object.values(data);

            $('#myModal').modal('show');
            let name = $(this).closest('.product__item').find('.product__item__name').text();

            if(chart){
                chart.data.labels = dates;
                chart.data.datasets.forEach((dataset) => {
                    dataset.data = sold;
                });
                chart.options.plugins.title.text = name;
                chart.update();
                return null;
            }

            chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dates,
                    datasets: [{
                        label: 'Đã bán',
                        data: sold,
                        borderWidth: 1,
                        borderColor: 'red',
                        fill: false,
                        cubicInterpolationMode: 'monotone',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: name
                        },
                        legend: {
                            display: false
                        }
                    },
                    interaction: {
                        intersect: false,
                    },
                    scales: {
                        x: {
                            display: true,
                            title: {
                                display: true
                            },
                            ticks: {
                                callback: function(value, index, ticks) {
                                    return moment(this.chart.data.labels[index], 'YYYY-MM-DD HH:mm').format('DD/MM/YYYY')
                                }
                            }
                        },
                        y: {
                            display: true,
                            title: {
                                display: true,
                                text: 'Số lượng đã bán'
                            },
                            ticks: {
                                precision: 0
                            }
                            // suggestedMin: -10,
                            // suggestedMax: 10
                        }
                    }
                },
            });
        });
    });
});