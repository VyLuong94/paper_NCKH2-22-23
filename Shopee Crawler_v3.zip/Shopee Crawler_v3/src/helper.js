const delay = timeout => new Promise(resolve => setTimeout(resolve, timeout));

function formatPrice(price) {
    price = price/100000;
    return (price || '0').toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

function shopUrl(item) {
    if(!item){
        return '#';
    }
    return `https://shopee.vn/${encodeURIComponent(item.name)}-i.${item.shop_id}.${item.id}`;
}

function shopImage(item) {
    if(!item){
        return '#';
    }
    return `https://cf.shopee.vn/file/${item.image}_tn`;
}

function percentDiscount(item) {
    if(!item || item.price > item.price_before_discount){
        return '0';
    }
    return ((item.price_before_discount - item.price)*100/item.price_before_discount).toFixed(1);
}

module.exports = {
    delay,
    formatPrice,
    shopUrl,
    shopImage,
    percentDiscount
};